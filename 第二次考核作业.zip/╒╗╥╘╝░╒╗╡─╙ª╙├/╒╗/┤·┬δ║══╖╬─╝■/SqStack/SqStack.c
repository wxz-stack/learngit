
#include "SqStack.h"
#include "stdio.h"
#include "stdlib.h"

/**
 *  @name        : Status initStack(SqStack *s,int sizes)
 *	@description : initialize an empty linked stack with the head node and the sizes without value
 *	@param		 : SqStack *s,int sizes
 *	@return		 : Status
 *  @notice      : None
 */
Status initStack(SqStack* s, int sizes)
{
	s->elem = (ElemType*)malloc(sizes * sizeof(ElemType));
	if (!s->elem)
		return ERROR;
	s->top = -1;
	s->size = sizes;
	return SUCCESS;
}

/**
 *  @name        : Status isEmptyStack(SqStack* s)
 *	@description : empty a stack
 *	@param		 : SqStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status isEmptyStack(SqStack* s)
{
	return s->top == -1;
}

/**
 *  @name        : Status getTopStack(SqStack* s, ElemType* e)
 *	@description : get top stack
 *	@param		 : SqStack* s,ElemType* e
 *	@return		 : Status
 *  @notice      : None
 */
Status getTopStack(SqStack* s, ElemType* e)
{
	if (s->top == -1)
		return ERROR;
	*e = s->elem[s->top];
	return SUCCESS;
}



/**
 *  @name        : Status clearStack(SqStack* s)
 *	@description : clear stack
 *	@param		 : SqStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status clearStack(SqStack* s)
{
	if (!s)
		return ERROR;
	s->top = -1;
	return SUCCESS;
}
/*
 *  @name        : Status destroyStack(SqStack* s)
 *	@description : destory stack
 *	@param		 : SqStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status destroyStack(SqStack* s)
{
	if (!s)
		return ERROR;
	free(s);
	return SUCCESS;
}

/**
 *  @name        : Status stackLength(SqStack* s, int* length);
 *	@description : get the length of the stack.
 *	@param		 : Status
 *	@return		 : None
 *  @notice      : None
 */
Status stackLength(SqStack* s, int* length)
{
	if (!s)
		return ERROR;
	*length = s->top + 1;
	return SUCCESS;
}
/**
 *  @name        : Status pushStack(SqStack* s, ElemType data)
 *	@description : push stack
 *	@param		 : SqStack* s, ElemType data
 *	@return		 : Status
 *  @notice      : None
 */
Status pushStack(SqStack* s, ElemType data)
{
	if (!s || s->top == s->size - 1)		//�ж�ջ�Ƿ�����
		return ERROR;
	s->top++;
	s->elem[s->top] = data;
	return SUCCESS;
}
/*
 *  @name        : Status pushStack(SqStack* s, ElemType data)
 *	@description : push stack
 *	@param		 : SqStack* s, ElemType data
 *	@return		 : Status
 *  @notice      : None
 */
Status popStack(SqStack* s, ElemType* data)
{
	if(!s || s->top == - 1)
		return ERROR;
	*data = s->elem[s->top];
	s->top--;
	return SUCCESS;
}

/**
 *  @name        : void System_interact(void);
 *	@description : initialize an system interface.
 *	@param		 : None
 *	@return		 : None
 *  @notice      : None
 */

void System_interact(void)
{
	printf("\n\n\t\t*******************************************\n");
	printf("\t\t*              ˳��ջ����ϵͳ             *\n");
	printf("\t\t*             1.��ʼ��ջ                  *\n");
	printf("\t\t*             2.�ж�ջ�Ƿ�Ϊ��            *\n");
	printf("\t\t*             3.�õ�ջ��Ԫ��              *\n");
	printf("\t\t*             4.���ջ                    *\n");
	printf("\t\t*             5.����ջ                    *\n");
	printf("\t\t*             6.���ջ����                *\n");
	printf("\t\t*             7.��ջ                      *\n");
	printf("\t\t*             8.��ջ                      *\n");
	printf("\t\t*             0.�˳�ϵͳ                  *\n");
	printf("\t\t*******************************************\n");

}

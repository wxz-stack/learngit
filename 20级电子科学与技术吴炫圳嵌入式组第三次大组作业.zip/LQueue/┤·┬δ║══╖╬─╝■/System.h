#ifndef __SYSTEM_H_INCLUDE
#define __SYSTEM_H_INCLUDE

void System_interact(void);//ϵͳ����

#endif // __SYSTEM_H_INCLUDE

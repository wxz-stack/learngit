#include "stdio.h"
#include "stdlib.h"
#include "LQueue2.h"
#include "string.h"
/***************************************************************************************
 *	FileName					:
 *	CopyRight					:
 *	ModuleName					:
 *
 *	CPU							:
 *	RTOS						:
 *
 *	Create Data					:
 *	Author/Corportation			:
 *
 *	Abstract Description		:
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/


/**************************************************************
*	Debug switch Section
**************************************************************/


/**************************************************************
*	Include File Section
**************************************************************/


/**************************************************************
*	Macro Define Section
**************************************************************/
//debug���Ժ궨�壬���ݱ���ʽa�����ִ��has_bug��no_bug
#define BUG_DETECT_PRINT(a,has_bug,no_bug) { if(a) \
printf("%s",has_bug); \
else \
printf("%s",no_bug);}


/**************************************************************
*	Struct Define Section
**************************************************************/


/**************************************************************
*	Prototype Declare Section
**************************************************************/

/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void InitLQueue(LQueue *Q)
{
	Node *p = (Node *)malloc(sizeof(Node));
	if (p == NULL)
	{
		printf("����ռ�ʧ�ܣ�");
		return;
	}
	else
	{
		printf("����ռ�ɹ���");
	}
	p->next = NULL;
	Q->front = p;
	Q->rear = p;
	return;
}

/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q)
{
	if(Q == NULL)
	{
		printf("�ö��л�δ��ʼ����");
		return;
	}
	while(Q->front!=NULL)
	{
		Q->rear = Q->front->next;
		free(Q->front);
		Q->front = Q->rear;
	}
	printf("���ٳɹ�");
	return;

}

/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *    @description : �������Ƿ�Ϊ��
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsEmptyLQueue(const LQueue *Q)
{
	/*if(Q == NULL)
	{
		printf("�ö��л�δ��ʼ����");
		return 	FALSE;
	}
	return(Q->rear == NULL);*/
	if(Q->front == Q->rear)
	{
		return TRUE;
	}
	else{
		return FALSE;
	}


}

/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *    @description : �鿴��ͷԪ��
 *    @param         Q e ����ָ��Q,��������ָ��e
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ��
 */
Status GetHeadLQueue(LQueue *Q)
{
	//void *e;
	if(Q == NULL)
	{
		printf("�ö��л�δ��ʼ����");
		return FALSE;
	}
	if(Q->front == Q->rear)
	{
		printf("�ö���Ϊ�գ�");
		return FALSE;
	}
	//memcpy(e, Q->front->next->data, Q->length);
	printf("�ɹ��õ�ͷԪ�أ�");
	*fooo(Q->front->next->data,datatype[0]);
	return TRUE;
}

/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *    @description : ȷ�����г���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q)
{
	int i;//���泤��
	Node *p = (Node *)malloc(sizeof(Node));
	p = Q->front;
	for (i = 0; p != Q->rear; i++)
	{
			p = p->next;
	}
	return i;
}

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ�Ϊ��
 */
Status EnLQueue(LQueue *Q, void *data)
{
	Node *p = (Node *)malloc(sizeof(Node));
	if (NULL == p)
	{
		printf("����ռ�ʧ�ܣ�");
		return FALSE;
	}

	p->data = (void *)malloc(Q->length);
	memcpy(p->data, data, Q->length);
	p->next = NULL;
	Q->rear->next = p;
	Q->rear = p;
	return TRUE;

}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q)
{
	if(Q == NULL)
	{
		printf("�ö��л�δ��ʼ����");
		return FALSE;
	}
	if(Q->front == Q->rear)
	{
		printf("�ö���Ϊ�գ�");
		return FALSE;
	}
      	Node *p = (Node *)malloc(sizeof(Node));
	p = Q->front->next;
	Q->front->next = p->next;
	if (NULL == Q->front->next)
	{
		Q->rear = Q->front;
	}
	free(p);
	return TRUE;
}

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q)
{
	if(Q->front == Q->rear)
	{
		printf("�ö���Ϊ�գ�");
		return;
	}
	int i;
	Node* q,*p;
	p = Q->front->next;
	Q->front->next = NULL;
	while(!i)
	{
		q = p->next;
		free(p);
		p = q;
		i = IsEmptyLQueue(Q);
	}
	Q->rear = Q->front;
	printf("��ճɹ���");
	return;

}

/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *    @description : ������������
 *    @param         Q ����ָ��Q����������ָ��foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseLQueue(const LQueue *Q, void (*fooo)(void *q,int p))
{
	if(Q->front == Q->rear)
	{
		printf("�ö���Ϊ�գ�");
		return FALSE;
	}
	Node* p = (void *)malloc(Q->length);
	p = Q->front->next;
	int i = 0,j = 0;
	while (p!=NULL)
	{
		fooo(p->data, datatype[i]);
		printf("\t");
		p = p->next;
		i++;
		if (i % 9 == 0)
		{
			printf("\n");
		}
	}
	printf("\n");
	return TRUE;
}


/**
 *  @name        : void LPrint(void *q)
 *    @description : ��������
 *    @param         q ָ��q

 *  @notice      : None
 */
void LLPrint(void *q,int p)
{
	if(p == 4)
		printf(" %s ", (char*)q);
        if(p == 3)
            printf(" %.2lf", *(double*)q);
        if(p == 2)
            printf(" %c", *(char*)q);
        if(p == 1)
            printf(" %d ", *(int*)q);
	printf("-<");
}

/**
 *  @name        : void *fooo(void*q,int p)
 *    @description : ���ָ��
 *    @param         q ָ��q������p

 *  @notice      : None
 */
void *fooo(void*q,int p)
{
	LLPrint(q,p);
}
/**************************************************************
*	Global Variable Declare Section
**************************************************************/


/**************************************************************
*	File Static Variable Define Section
**************************************************************/


/**************************************************************
*	Function Define Section
**************************************************************/

/**
 *  @name
 *	@description
 *	@param
 *	@return
 *  @notice
 */



 #ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{
          /* User can add his own implementation to report the file name and line number,
             ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

          while (1)
          {}
}
#endif




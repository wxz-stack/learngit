#include "stdio.h"
#include "stdlib.h"
#include "caculator.h"

int main()
{
	char str[1000] = {0};
	ElemType i = 0,tmp = 0,a,n = 10;
        LinkStack s_num,s_opt;
	if(!initLStack(&s_num) || (!initLStack(&s_opt)))
	{
		printf("��ʼ��ʧ�ܣ�\n");
		return 0;
	}
	printf("������Ҫ����ı���ʽ\n");
	for(i = 0;i < n;i++)
		scanf("%c",&str[i]);
	while(str[i] !='\0'|| isEmptyLStack(&s_opt) != SUCCESS)
	{
		if(str[i] >= '0'&&str[i] <= '9')
		{
			tmp = tmp * 10 + str[i] - '0';
			i++;
			if (str[i] < '0' || str[i] > '9')
			{
				pushLStack(&s_num, tmp);
				tmp = 0;
			}
		}

		else
		{
			if (isEmptyLStack(&s_opt) == SUCCESS|| (getTopLStack(&s_opt) == '(' && str[i] != ')') || Priority(str[i]) > Priority(getTopLStack(&s_opt)))
			{
				pushLStack(&s_opt, str[i]);
				i++;
				continue;
			}
			if (getTopLStack(&s_opt) == '(' && str[i] == ')')
			{
				popLStack(&s_opt);
				i++;
				continue;
			}
			if ((str[i] == '\0' && isEmptyLStack(&s_opt) != SUCCESS) || str[i] == ')' && getTopLStack(&s_opt) != '(' ||
				Priority(str[i]) <= Priority(getTopLStack(&s_opt)))
			{
				switch(popLStack(&s_opt))
				{
				case '+':
					pushLStack(&s_num,popLStack(&s_num)+popLStack(&s_num));
					break;
				case '-':
					a = popLStack(&s_num);
					pushLStack(&s_num,popLStack(&s_num)-a);
					break;
				case '*':
					pushLStack(&s_num,popLStack(&s_num)*popLStack(&s_num));
					break;
				case '/':
					a = popLStack(&s_num);
					pushLStack(&s_num,popLStack(&s_num)/a);
					break;
				}
				continue;
			}

		}
	}
	printf("������Ϊ%d��\n",popLStack(&s_num));
	return 0;

}

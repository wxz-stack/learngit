#include "caculator.h"
#include "stdio.h"
#include "stdlib.h"

/**
 *  @name        : Status initStack(LinkStack *s,int sizes)
 *	@description : initialize an empty linked stack with the head node and the sizes without value
 *	@param		 : LinkStack *s
 *	@return		 : Status
 *  @notice      : None
 */
Status initLStack(LinkStack* s)
{
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	if (!s->top)
		return ERROR;
	s->count = 0;
	return SUCCESS;
}

/**
 *  @name        : Status isEmptyStack(LinkStack* s)
 *	@description : empty a stack
 *	@param		 : LinkStack* s
 *	@return		 : Status
 *  @notice      : None
 */

Status isEmptyLStack(LinkStack* s)
{
	if(s->count == 0)
		return SUCCESS;
	return ERROR;
}

/**
 *  @name        : Status getTopStack(LinkStack* s, ElemType* e)
 *	@description : get top stack
 *	@param		 : LinkStack* s
 *	@return		 : Status
 *  @notice      : None
 */
int getTopLStack(LinkStack* s)
{
	if (!s->top||s->count==0)
		return ERROR;
	return s->top->data;
}

/**
 *  @name        : Status pushLStack(LinkStack* s, ElemType data)
 *	@description : push stack
 *	@param		 : LinkStack* s, ElemType data
 *	@return		 : Status
 *  @notice      : None
 */
Status pushLStack(LinkStack* s, ElemType data)
{
	StackNode* Q;
	Q = (StackNode*)malloc(sizeof(StackNode));
	if (!s->top)		//�ж�ջ�Ƿ����
		return ERROR;
	Q->data = data;
	Q->next = s->top;
	s->top = Q;
	s->count++;
	return SUCCESS;
}

/*
 *  @name        : int popLStack(LinkStack* s)
 *	@description : push stack
 *	@param		 : LinkStack* s
 *	@return		 : data
 *  @notice      : None
 */
int popLStack(LinkStack* s)
{
	ElemType data;
	LinkStackPtr P = s->top;
	if(s->count==0 || !s->top)
		return ERROR;
	data = P->data;
	s->top = P->next;
	free(P);
	s->count--;
	return data;
}

/*
 *  @name        : int Priority(char s)
 *	@description : compare the priority
 *	@param		 : char s
 *	@return		 : 0,1,2,3
 *  @notice      : None
 */
int Priority(char s)
{
	switch(s)
	{
	case '(':
		return 3;
	case '*':
		return 2;
	case '/':
		return 2;
	case '+':
		return 1;
	case '-':
		return 1;
	default:
		return 0;
	}
}

#include "LinkStack.h"
#include "stdio.h"
#include "stdlib.h"

/**
 *  @name        : Status initStack(LinkStack *s,int sizes)
 *	@description : initialize an empty linked stack with the head node and the sizes without value
 *	@param		 : LinkStack *s
 *	@return		 : Status
 *  @notice      : None
 */
Status initLStack(LinkStack* s)
{
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	if (!s->top)
		return ERROR;
	s->count = 0;
	return SUCCESS;
}

/**
 *  @name        : Status isEmptyStack(LinkStack* s)
 *	@description : empty a stack
 *	@param		 : LinkStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status isEmptyLStack(LinkStack* s)
{
	if(s->count==0)
		return SUCCESS;
	return ERROR;
}

/**
 *  @name        : Status getTopStack(LinkStack* s, ElemType* e)
 *	@description : get top stack
 *	@param		 : LinkStack* s,ElemType* e
 *	@return		 : Status
 *  @notice      : None
 */
Status getTopLStack(LinkStack* s, ElemType* e)
{
	if (!s->top||s->count==0)
		return ERROR;
	*e = s->top->next->data;
	return SUCCESS;
}



/**
 *  @name        : Status clearStack(LinkStack* s)
 *	@description : clear stack
 *	@param		 : LinkStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status clearLStack(LinkStack* s)
{
	/*StackNode *p;
	if(!s->top)
		return ERROR;
	while(s)                  //ѭ���ͷŽڵ�
	{
        p = s;
        s = s->top->next;
        free(p);
	}*/
	ElemType a;
	LinkStackPtr Q;
	LinkStackPtr P = s->top->next;
	if (!s->top)
		return ERROR;
	while(!a)
	{
		Q = P->next;
		free(P);
		P = Q;
		a = isEmptyLStack(s);
	}
	s->count = 0;
	return SUCCESS;
}
/*
 *  @name        : Status destroyStack(LinkStack* s)
 *	@description : destory stack
 *	@param		 : LinkStack* s
 *	@return		 : Status
 *  @notice      : None
 */
Status destroyLStack(LinkStack* s)
{
	LinkStackPtr Q;
	LinkStackPtr P = s->top->next;
	while(s->count)
	{
		Q = P->next;
		free(P);
		s->top->next = Q;
		s->count--;
	}
	free(s->top);
	return SUCCESS;
}

/**
 *  @name        : Status LStackLength(LinkStack* s, int* length);
 *	@description : get the length of the stack.
 *	@param		 : Status
 *	@return		 : None
 *  @notice      : None
 */
Status LStackLength(LinkStack* s, int* length)
{
	if (!s)
		return ERROR;
	*length = s->count;
	return SUCCESS;
}
/**
 *  @name        : Status pushStack(LinkStack* s, ElemType data)
 *	@description : push stack
 *	@param		 : LinkStack* s, ElemType data
 *	@return		 : Status
 *  @notice      : None
 */
Status pushLStack(LinkStack* s, ElemType data)
{
	StackNode* Q;
	Q = (StackNode*)malloc(sizeof(StackNode));
	if (!s->top)		//�ж�ջ�Ƿ����
		return ERROR;
	Q->data = data;
	Q->next = s->top->next;
	s->top->next = Q;
	s->count = s->count + 1;
	return SUCCESS;
}
/*
 *  @name        : Status pushStack(LinkStack* s, ElemType data)
 *	@description : push stack
 *	@param		 : LinkStack* s, ElemType data
 *	@return		 : Status
 *  @notice      : None
 */
Status popLStack(LinkStack* s, ElemType* data)
{
	LinkStackPtr Q;
	LinkStackPtr P = s->top->next;
	if(s->count==0 || !s->top)
		return ERROR;
	*data = P->data;
	Q = P->next;
	free(P);
	s->top->next = Q;
	s->count--;
	return SUCCESS;
}

/**
 *  @name        : void System_interact(void);
 *	@description : initialize an system interface.
 *	@param		 : None
 *	@return		 : None
 *  @notice      : None
 */

void System_interact(void)
{
	printf("\n\n\t\t*******************************************\n");
	printf("\t\t*              ˳��ջ����ϵͳ             *\n");
	printf("\t\t*             1.�˳�ϵͳ                  *\n");
	printf("\t\t*             2.�ж�ջ�Ƿ�Ϊ��            *\n");
	printf("\t\t*             3.�õ�ջ��Ԫ��              *\n");
	printf("\t\t*             4.���ջ                    *\n");
	printf("\t\t*             5.����ջ                    *\n");
	printf("\t\t*             6.���ջ����                *\n");
	printf("\t\t*             7.��ջ                      *\n");
	printf("\t\t*             8.��ջ                      *\n");
	printf("\t\t*             0.��ʼ��ջ                  *\n");
	printf("\t\t*******************************************\n");

}

